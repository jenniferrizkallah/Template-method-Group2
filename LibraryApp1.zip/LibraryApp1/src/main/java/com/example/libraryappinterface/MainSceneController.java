package com.example.libraryappinterface;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

import com.libraryappcontroller.Book;
import com.libraryappcontroller.MYSQLConnector;
import com.libraryappcontroller.MYSQLDatabaseManager;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Tab;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import static com.example.libraryappinterface.accounts.stmt;

public class MainSceneController implements Initializable {

    @FXML
    private TableView<Book> tableBooks;
    @FXML
    private TableColumn<Book, Integer> col_ISBN;

    @FXML
    private TableColumn<Book, String> col_author;

    @FXML
    private TableColumn<Book, Integer> col_edition;

    @FXML
    private TableColumn<Book, String> col_genre1;


    @FXML
    private TableColumn<Book, String> col_pubdate;

    @FXML
    private TableColumn<Book, String> col_publisher;

    @FXML
    private TableColumn<Book, String> col_title;

    @FXML
    private Tab tabText;

    @FXML
    private Tab tabText1;

    ObservableList<Book> listM;
    ObservableList<Book> dataList;
    String query = null;
    Connection conn = null ;
    PreparedStatement pst = null ;
    ResultSet rs = null ;
    Book book = null ;

    public MainSceneController() {
    }

    ObservableList<Book>  books = FXCollections.observableArrayList();;

    public void initialize(URL url, ResourceBundle rb) {
        try {

            conn = MYSQLConnector.connect();
            query = "SELECT * FROM `book`";
            pst = conn.prepareStatement(query);
            rs = pst.executeQuery();

            while (rs.next()){
                books.add(new  Book(
                        rs.getInt("ISBN"),
                        rs.getString("title"),
                        rs.getString("author"),
                        rs.getString("publisher"),
                        rs.getInt("edition"),
                        rs.getString("pubdate"),
                        rs.getString("genre1")));
                tableBooks.setItems(books);

            }

    } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        col_ISBN.setCellValueFactory(new PropertyValueFactory<>("ISBN"));
        col_title.setCellValueFactory(new PropertyValueFactory<>("title"));
        col_author.setCellValueFactory(new PropertyValueFactory<>("author"));
        col_author.setCellValueFactory(new PropertyValueFactory<>("publisher"));
        col_edition.setCellValueFactory(new PropertyValueFactory<>("edition"));
        col_pubdate.setCellValueFactory(new PropertyValueFactory<>("pubdate"));
        col_genre1.setCellValueFactory(new PropertyValueFactory<>("genre1"));
    }
}


