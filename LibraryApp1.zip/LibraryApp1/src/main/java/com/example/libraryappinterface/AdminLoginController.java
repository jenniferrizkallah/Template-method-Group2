package com.example.libraryappinterface;

import java.io.IOException;
import java.sql.SQLException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class AdminLoginController {
    private String Password, Username;
    @FXML
    TextField UsernameTextField;
    @FXML
    TextField PasswordTextField;

    public void getCredentials(ActionEvent e) throws IOException, SQLException {
        Password = PasswordTextField.getText();
        Username = UsernameTextField.getText();
        goToMainScene(e);
    }

    public void goToMainScene(ActionEvent e) throws IOException, SQLException {
        if (accounts.validateAccount(Username , Password)) {
            Stage stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
            Parent root = FXMLLoader.load(getClass().getResource("MainScene.fxml"));
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        }
    }

    public void goToLoginScene(ActionEvent e) throws IOException {
        Stage stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        Parent root = FXMLLoader.load(getClass().getResource("Login.fxml"));
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
}
