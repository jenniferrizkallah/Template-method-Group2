package com.example.libraryappinterface;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class SignupController  {
    String Username, Password, FirstName, LastName, ConfirmationOfPassword,DateOfBirth;

    @FXML
    private TextField FirstNameField;
    @FXML
    private TextField LastNameField;
    @FXML
    private TextField UsernameField;
    @FXML
    private TextField PasswordField;
    @FXML
    private TextField PasswordConfirmationField;
    @FXML
    private ChoiceBox TypeOfAccountChoiceBox;
    @FXML
    private Label PasswordDont;
    @FXML
    private Label match;
    @FXML
    private TextField DateOfBirthField;

    protected String TypeChosen;

    protected String AccountPriority;


    private void getType(Event e) {
        TypeChosen = (String) TypeOfAccountChoiceBox.getValue();
    }

    public void getCredentials(ActionEvent e) throws SQLException {
        if (!PasswordConfirmed()) {
            PasswordDont.setVisible(true);
            match.setVisible(true);
        } else {
            FirstName = FirstNameField.getText();
            LastName = LastNameField.getText();
            Username = UsernameField.getText();
            Password = PasswordField.getText();
            ConfirmationOfPassword = PasswordConfirmationField.getText();
            DateOfBirth = DateOfBirthField.getText();
            accounts.add_a_client(Username,FirstName,LastName,Password,DateOfBirth);
        }
    }

    public void goToLoginScene(ActionEvent e) throws IOException {
        Stage stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        Parent root = FXMLLoader.load(getClass().getResource("Login.fxml"));
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public boolean PasswordConfirmed() {
        return ConfirmationOfPassword.equals(Password);
    }

}
