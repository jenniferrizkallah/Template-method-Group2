package com.libraryappcontroller;

public class Transaction {
    public Transaction(){

    }
}
