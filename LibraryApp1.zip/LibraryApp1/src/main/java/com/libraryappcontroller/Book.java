package com.libraryappcontroller;

public class Book {
    int ISBN, edition;
    String title,author,publisher,pubdate,genre1;
    public Book(int iSBN, String title, String author, String publisher, int edition, String pubdate,
                       String genre1) {
        super();
        ISBN = iSBN;
        this.title = title;
        this.author = author;
        this.publisher = publisher;
        this.edition = edition;
        this.pubdate = pubdate;
        this.genre1 = genre1;

    }
    protected int getISBN() {
        return ISBN;
    }
    protected void setISBN(int iSBN) {
        ISBN = ISBN;
    }
    protected String getTitle() {return title;}
    protected void setTitle(String title) {
        this.title = title;
    }
    protected String getAuthor() {
        return author;
    }
    protected void setAuthor(String author) {
        this.author = author;
    }
    protected String getPublisher() {
        return publisher;
    }
    protected void setPublisher(String publisher) {
        this.publisher = publisher;
    }
    protected int getEdition() {
        return edition;
    }
    protected void setEdition(int edition) {
        this.edition = edition;
    }
    protected String getPubdate() {
        return pubdate;
    }
    protected void setPubdate(String pubdate) {
        this.pubdate = pubdate;
    }
    protected String getGenre1() {
        return genre1;
    }
    protected void setGenre1(String genre1) {
        this.genre1 = genre1;
    }


}
