module com.example.libraryapp1 {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    opens com.example.libraryappinterface to javafx.fxml;
    exports com.example.libraryappinterface;
}